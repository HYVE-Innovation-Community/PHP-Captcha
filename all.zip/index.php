<html>
    <head>
        <title>CAPTCHA</title>
    </head>
    <body bgcolor="#CCCCCC">
        <img src="captcha.php" />
        <form action="check.php" method="post">
            <input type="text" name="captcha" />
            <br/>
            <input type="submit" name="submit" value="Abschicken!" />
        </form>
    </body>
</html>